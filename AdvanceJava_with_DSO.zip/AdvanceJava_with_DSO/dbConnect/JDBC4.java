import java.sql.*;
import java.util.*;
class JDBC4{
	public static void main(String[] args){
		Connection con = null;
		PreparedStatement pst;
		Scanner sc = new Scanner(System.in);
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
			System.out.print("Enter ID: ");
			int gid = sc.nextInt();
			System.out.print("Enter Name: ");
			String gname = sc.next();
			System.out.print("Enter Age: ");
			int gage = sc.nextInt();
			System.out.print("Enter Address: ");
			String gaddress = sc.next();
			pst = con.prepareStatement("insert into record values(?,?,?,?)");
			pst.setInt(1,gid);
			pst.setString(2,gname);
			pst.setInt(3,gage);
			pst.setString(4,gaddress);
			int res = pst.executeUpdate();
			if(res!=0){
				System.out.println("Record inserted");
			}else{
				System.out.println("Record not inserted");
			}
			con.close();
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
}