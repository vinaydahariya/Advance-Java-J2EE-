import java.sql.*;
import java.util.*;
class JDBC1{
    public static void main(String[] args){
         Connection con = null;
         Statement st;
         ResultSet rs;
	Scanner sc = new Scanner(System.in);
         try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
	    int gid;
	    System.out.print("Enter ID: ");
	    gid = sc.nextInt();
	    String sql = "select *from record where id="+gid+"";
	    st = con.createStatement();
	    rs = st.executeQuery(sql);	
            if(rs.next()){
		System.out.println("Name="+rs.getString(2));
		System.out.println("Age="+rs.getInt(3));
		System.out.println("Address="+rs.getString(3));
	    }else{
		System.out.println("No record found");
	    }		
	    con.close();
         }catch(Exception e){
            System.out.println(e.toString());
         }   
    }
}