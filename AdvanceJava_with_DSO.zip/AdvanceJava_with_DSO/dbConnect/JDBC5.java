import java.sql.*;
import java.util.*;

class JDBC5{
	public static void main(String[] args){
		Connection con = null;
		CallableStatement cst;
		Scanner sc = new Scanner(System.in);
		try{
			Class.forName("com.mysql.jdbc.Driver");
           		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
			cst = con.prepareCall("{call INSERTR(?,?,?,?)}");
			System.out.print("Enter ID: ");
			int gid = sc.nextInt();
			System.out.print("Enter Name: ");
			String gname = sc.next();
			System.out.print("Enter Age: ");
			int gage = sc.nextInt();
			System.out.print("Enter Address: ");
			String gaddress = sc.next();
			cst.setInt(1,gid);
			cst.setString(2,gname);
			cst.setInt(3,gage);
			cst.setString(4,gaddress);
			cst.execute();
			System.out.println("Record Inserted");
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
}