import java.sql.*;
import java.util.*;

class JDBC2{
	public static void main(String[] args){
		Connection con = null;
		Statement st;
		ResultSet rs;
		Scanner sc = new Scanner(System.in);
		try{
			Class.forName("com.mysql.jdbc.Driver");
           		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
			System.out.print("Enter ID: ");
			int gid = sc.nextInt();
			System.out.print("Enter Name: ");
			String gname = sc.next();
			System.out.print("Enter Age: ");
			int gage = sc.nextInt();
			System.out.print("Enter Address: ");
			String gaddress = sc.next();
			String sql = "INSERT INTO record VALUES (" + gid + ", '" + gname + "', " + gage + ", '" + gaddress + "')";
			st = con.createStatement();
			int res = st.executeUpdate(sql);
			if(res!=0){
				System.out.println("Record Inserted");
			}else{
				System.out.println("Record Not Inserted");
			}
			
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
}