import java.sql.*;
class Main{
    public static void main(String[] args){
         Connection con = null;
         Statement st;
         ResultSet rs;
         try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("Select *from record");
            System.out.println("ID\tName\tAge\tAddress");
            while(rs.next()){
                System.out.print(rs.getInt(1)+"\t");
                System.out.print(rs.getString(2)+"\t");
                System.out.print(rs.getInt(3)+"\t");
                System.out.println(rs.getString(4));
            }
         }catch(Exception e){
            System.out.println(e.toString());
         }   
    }
}