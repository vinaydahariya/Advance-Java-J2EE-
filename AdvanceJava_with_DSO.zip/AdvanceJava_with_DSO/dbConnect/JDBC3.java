import java.sql.*;
import java.util.*;
class JDBC3{
	public static void main(String[] args){
		Connection con;
		Statement st;
		ResultSet rs;
		Scanner sc = new Scanner(System.in);
		try{
			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
			System.out.print("Enter Id: ");
			int gid = sc.nextInt();
			st = con.createStatement();
			int res = st.executeUpdate("delete from record where id="+gid+"");
			if(res!=0){
				System.out.println("Record Deleted");
			}else{
				System.out.println("Record Not Deleted");
			}
			con.close();
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
}