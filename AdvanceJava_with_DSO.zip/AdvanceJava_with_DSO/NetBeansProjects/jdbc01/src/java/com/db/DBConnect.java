package com.db;
import java.sql.*;
public class DBConnect {
    Connection con=null;
    public Connection getConnect(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return con;
    }
}
