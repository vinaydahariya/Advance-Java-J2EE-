package com.servletdemo;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class hello implements Servlet {
    ServletConfig config;
    String name;

    public void init(ServletConfig config) throws ServletException {
        this.config = config; // Correctly assigning the parameter to the instance variable
        name = "vinay";       // Initializing name
    }

    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html><body>");
        out.println("<h1>This is a Simple Servlet</h1>");
        out.println("<h3>Developed for me: " + name + "</h3>"); // Displaying the name
        out.println("</body></html>");
    }

    public void destroy() {
        // Cleanup code, if needed
    }

    public ServletConfig getServletConfig() {
        return config;
    }

    public String getServletInfo() {
        return "Developed By Vinay";
    }
}
