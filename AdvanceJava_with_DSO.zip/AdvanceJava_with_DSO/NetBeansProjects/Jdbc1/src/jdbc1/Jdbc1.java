/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jdbc1;

/**
 *
 * @author dahar
 */
import java.sql.*;

public class Jdbc1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection con = null;
         Statement st;
         ResultSet rs;
         try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dahariya", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("Select *from record");
            System.out.println("ID\tName\tAge\tAddress");
            while(rs.next()){
                System.out.print(rs.getInt(1)+"\t");
                System.out.print(rs.getString(2)+"\t");
                System.out.print(rs.getInt(3)+"\t");
                System.out.println(rs.getString(4));
            }
         }catch(Exception e){
            System.out.println(e.toString());
         }   

        
    }
    
}
