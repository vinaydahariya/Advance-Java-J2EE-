package com.learn;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class addservlet extends HttpServlet{
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.print("<html><body>");
        int a, b, c;
        a = Integer.parseInt(req.getParameter("t1"));
        b = Integer.parseInt(req.getParameter("t2"));
        c = a+b;
        out.println("Sum = "+c);
        out.println("</body></html>");
    }
}
