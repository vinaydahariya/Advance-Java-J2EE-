package com.learn;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import java.io.*;

@WebServlet("/hello")  // URL pattern for the servlet
public class hellogen extends GenericServlet {
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        try (PrintWriter out = res.getWriter()) {
            out.println("<html><body>");
            out.println("<h1>Hello Friends, This is a Generic Servlet</h1>");
            out.println("</body></html>");
        } catch (IOException e) {
            // Handle exception (log it, rethrow it, etc.)
            e.printStackTrace();
        }
    }
}
